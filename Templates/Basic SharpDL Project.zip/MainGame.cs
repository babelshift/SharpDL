﻿using SharpDL;
using SharpDL.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
	public class MainGame : Game
	{
		private const int SCREEN_WIDTH = 1296;
		private const int SCREEN_HEIGHT = 728;

		public MainGame()
		{
		}

		protected override void Initialize()
		{
			base.Initialize();

			CreateWindow("My Second SDL", 100, 100, SCREEN_WIDTH, SCREEN_HEIGHT, WindowFlags.Shown);
			CreateRenderer(RendererFlags.RendererAccelerated);
		}

		protected override void LoadContent()
		{
			base.LoadContent();
		}

		protected override void Update(GameTime gameTime)
		{
			base.Update(gameTime);
		}

		protected override void Draw(GameTime gameTime)
		{
			base.Draw(gameTime);
		}

		protected override void UnloadContent()
		{
			base.UnloadContent();
		}
	}
}
